#!/bin/bash
cd /var/www/html/plorg.net
mkdir dist_public
mkdir dist_public/scratchfolder
mkdir dist_public/sync
chmod 777 dist_public/scratchfolder
chmod 777 dist_public/sync
