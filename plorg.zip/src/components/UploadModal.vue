<template>
  <div class="uploadModal">
    <form class="my-form">
      <p>Upload multiple files with the file dialog or by dragging and dropping images onto the dashed region</p>
      <input type="file" id="fileElem" multiple accept="image/*" onchange="handleFiles(this.files)">
      <label class="button" for="fileElem">Select some files</label>
    </form>
  </div>
</template>

<script>

  export default{
    name: 'uploadModal',
    props: [ 'state'],
    data(){
      return{
      }
    },
    computed: {
    },
    methods:{
    },
    mounted(){
    }
  }
</script>

<style scoped>
.uploadModal{
  border: 1px solid white;
}
</style>

