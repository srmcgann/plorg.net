<?
  $db_user="user";
  $db_pass="chrome57253";
  $db_host="localhost";
  $db="generative";
  $maxResultsPerPage = 4;
  $masterDBSyncURL = 'https://ipfs.appliedlearning.academy/ipfs/QmVQsiEku4h2qxRYGMVeoaCfgCPEvJz9kN4rexHLi1xjns/2022_01_25_10_02_42.sql';
  $baseURL = 'plorg.net';
  $ipfsURL = 'https://ipfs.dweet.net/ipfs/';
  
  $link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>


