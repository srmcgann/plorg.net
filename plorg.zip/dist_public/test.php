<?
  function decToAlpha($val){
    $alphabet="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $ret="";
    while($val){
      $r=floor($val/62);
      $frac=$val/62-$r;
      $ind=(int)round($frac*62);
      $ret=$alphabet[$ind].$ret;
      $val=$r;
    }
    return $ret==""?"0":$ret;
  }

  //echo decToAlpha(2121777265) . "\n";

  die();
  //populate blank hashes

  require('db.php');
  $sql="SELECT * FROM users";
  $res = mysqli_query($link, $sql);
  for($i=0; $i<mysqli_num_rows($res); ++$i){
    $row = mysqli_fetch_assoc($res);
    if($row['hash']==''){
      $hash = md5($row['pkh'].strtotime('now').rand());
      $sql = "UPDATE users SET hash = \"$hash\" where id = " . $row['id'];
      mysqli_query($link, $sql);
    }
  }

  $sql="SELECT * FROM items";
  $res = mysqli_query($link, $sql);
  for($i=0; $i<mysqli_num_rows($res); ++$i){
    $row = mysqli_fetch_assoc($res);
    if($row['hash']==''){
      $hash = md5(hash_file('md5', $ipfsURL.$row['ipfs']).strtotime('now').rand());
      $sql = "UPDATE items SET hash = \"$hash\" where id = " . $row['id'];
      mysqli_query($link, $sql);
    }
  }

  $sql="SELECT * FROM comments";
  $res = mysqli_query($link, $sql);
  for($i=0; $i<mysqli_num_rows($res); ++$i){
    $row = mysqli_fetch_assoc($res);
    if($row['hash']==''){
      $sql="SELECT * FROM users WHERE id = " . $row['userID'];
      $res2=mysqli_query($link, $sql);
      $pkh=mysqli_fetch_assoc($res2)['pkh'];
      $hash = md5($pkh.strtotime('now').rand());
      $sql = "UPDATE comments SET hash = \"$hash\" where id = " . $row['id'];
      mysqli_query($link, $sql);
    }
  }
?>
