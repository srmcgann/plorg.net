#!/bin/bash
node /home/cantelope/puppeteer/main.js $1 $2 $3 $4 $5
