#!/bin/bash
cd $TEZOS_CLIENT_DIR
zip wallets.zip public_key_hashs public_keys secret_keys
