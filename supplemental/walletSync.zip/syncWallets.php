<?
  $ipfs_dir = '/usr/local/bin/ipfs';
  shell_exec($command = "sudo -u cantelope $ipfs_dir files mkdir /syncWallets");
  $ipfsBaseURL = explode("\n", file_get_contents('/home/cantelope/plorgIpfsURL'))[0];
  $walletDir = $ipfsBaseURL . explode("\n", shell_exec($command = "sudo -u cantelope $ipfs_dir files stat /syncWallets 2>&1"))[0];
  chdir($TEZOS_CLIENT_DIR=getenv('TEZOS_CLIENT_DIR'));
  @unlink('wallets.zip');
  shell_exec("rm -rf $TEZOS_CLIENT_DIR/temp");
  @mkdir("$TEZOS_CLIENT_DIR/temp");
  shell_exec('./zipWallets.sh');
  shell_exec("sudo -u cantelope $ipfs_dir files rm /syncWallets/wallets.zip 2>&1");
  $output = shell_exec("sudo -u cantelope $ipfs_dir add ./wallets.zip -q 2>&1");
  $ipfs_hash=($s=explode("\n", $output))[sizeof($s)-2];
  @unlink('wallets.zip');
  $output = shell_exec($command = "sudo -u cantelope $ipfs_dir files cp /ipfs/$ipfs_hash /syncWallets/wallets.zip 2>&1");
  $peer = explode("\n", file_get_contents('/home/cantelope/plorgPeer'))[0];
	$remoteWalletFileURL = file_get_contents($peer . '/links/curWalletLink.php');
	if($remoteWalletFileURL){
		shell_exec('wget ' . $remoteWalletFileURL);
    shell_exec('mv wallets.zip temp; cd temp; unzip wallets.zip');
    for($i=0; $i<3; ++$i){
			switch($i){
				case 0: $file = 'public_key_hashs'; break;
        case 1: $file = 'public_keys'; break;
        case 2: $file = 'secret_keys'; break;
			}
		  $current = filesize($file);
		  $new = filesize('./temp/' . $file);
      if(intval($new) > 0 && $new > $current){
				$jsonCurrent = json_decode(file_get_contents($file));
				$jsonNew = json_decode(file_get_contents('./temp/'.$file));
        for($j=0; $j<sizeof($jsonNew);++$j){
          $newName = $jsonNew[$j]->{'name'};
					$inFile = false;
          for($k=0; $k<sizeof($jsonCurrent);++$k){
            if($newName == $jsonCurrent[$k]->{'name'}){
              $inFile = true;
            }
          }
					if(!$inFile){
            array_push($jsonCurrent, $jsonNew[$j]);
          }
        }
				file_put_contents($file, json_encode($jsonCurrent));
      }
		}
    shell_exec("rm -rf $TEZOS_CLIENT_DIR/temp");
    echo "wallets updated\n";
  } else {
		echo "remote wallet file could not be downloaded\n";
	}
?>
